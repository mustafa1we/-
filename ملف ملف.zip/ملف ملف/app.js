// بيانات التطبيق
let products = [
    { id: 1, name: "قلم حبر أزرق", price: 2.5, category: "أقلام", stock: 100 },
    { id: 2, name: "دفتر جامعي", price: 10, category: "دفاتر", stock: 50 },
    // المزيد من المنتجات
];

let customers = [
    { id: 1, name: "مدرسة النجاح", phone: "0512345678" },
    // المزيد من العملاء
];

let sales = [];

// متغيرات الفاتورة الحالية
let currentInvoice = {
    customerId: 0,
    items: [],
    date: new Date()
};

// عند تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    loadProducts();
    loadCustomers();
    
    // أحداث البحث والتصفية
    document.getElementById('productSearch').addEventListener('input', filterProducts);
    document.getElementById('categoryFilter').addEventListener('change', filterProducts);
    
    // حدث إتمام البيع
    document.getElementById('completeSale').addEventListener('click', completeSale);
});

// تحميل المنتجات في الشبكة
function loadProducts() {
    const productGrid = document.getElementById('productGrid');
    productGrid.innerHTML = '';
    
    products.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'col-6 col-md-4 col-lg-3 mb-3';
        productCard.innerHTML = `
            <div class="card product-card" data-id="${product.id}">
                <div class="card-body text-center">
                    <h6 class="card-title">${product.name}</h6>
                    <p class="card-text">${product.price} ر.س</p>
                    <button class="btn btn-sm btn-primary add-to-invoice">إضافة</button>
                </div>
            </div>
        `;
        productGrid.appendChild(productCard);
    });
    
    // إضافة أحداث لأزرار الإضافة
    document.querySelectorAll('.add-to-invoice').forEach(button => {
        button.addEventListener('click', addToInvoice);
    });
}

// تصفية المنتجات حسب البحث والفئة
function filterProducts() {
    const searchTerm = document.getElementById('productSearch').value.toLowerCase();
    const category = document.getElementById('categoryFilter').value;
    
    document.querySelectorAll('.product-card').forEach(card => {
        const productId = parseInt(card.getAttribute('data-id'));
        const product = products.find(p => p.id === productId);
        const matchesSearch = product.name.toLowerCase().includes(searchTerm);
        const matchesCategory = category === '' || product.category === category;
        
        card.style.display = (matchesSearch && matchesCategory) ? 'block' : 'none';
    });
}

// إضافة منتج للفاتورة
function addToInvoice(e) {
    const productId = parseInt(e.target.closest('.product-card').getAttribute('data-id'));
    const product = products.find(p => p.id === productId);
    
    // التحقق من وجود المنتج بالفعل في الفاتورة
    const existingItem = currentInvoice.items.find(item => item.productId === productId);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        currentInvoice.items.push({
            productId: product.id,
            name: product.name,
            price: product.price,
            quantity: 1
        });
    }
    
    updateInvoiceDisplay();
}

// تحديث عرض الفاتورة
function updateInvoiceDisplay() {
    const invoiceItems = document.getElementById('invoiceItems');
    invoiceItems.innerHTML = '';
    
    let total = 0;
    
    currentInvoice.items.forEach(item => {
        const row = document.createElement('tr');
        const itemTotal = item.price * item.quantity;
        total += itemTotal;
        
        row.innerHTML = `
            <td>${item.name}</td>
            <td>
                <input type="number" class="form-control form-control-sm quantity-input" 
                       value="${item.quantity}" min="1" data-id="${item.productId}">
            </td>
            <td>${item.price.toFixed(2)}</td>
            <td>${itemTotal.toFixed(2)}</td>
            <td><button class="btn btn-sm btn-danger remove-item" data-id="${item.productId}">×</button></td>
        `;
        invoiceItems.appendChild(row);
    });
    
    document.getElementById('totalAmount').textContent = total.toFixed(2);
    
    // إضافة أحداث لتعديل الكميات والحذف
    document.querySelectorAll('.quantity-input').forEach(input => {
        input.addEventListener('change', updateItemQuantity);
    });
    
    document.querySelectorAll('.remove-item').forEach(button => {
        button.addEventListener('click', removeItemFromInvoice);
    });
}

// إتمام عملية البيع
function completeSale() {
    if (currentInvoice.items.length === 0) {
        alert('الرجاء إضافة منتجات للفاتورة');
        return;
    }
    
    // حفظ عملية البيع
    const sale = {
        id: sales.length + 1,
        customerId: parseInt(document.getElementById('customerSelect').value),
        items: [...currentInvoice.items],
        total: parseFloat(document.getElementById('totalAmount').textContent),
        date: new Date()
    };
    
    sales.push(sale);
    
    // طباعة الفاتورة
    printInvoice(sale);
    
    // إعادة تعيين الفاتورة الحالية
    currentInvoice = {
        customerId: 0,
        items: [],
        date: new Date()
    };
    updateInvoiceDisplay();
    document.getElementById('customerSelect').value = '0';
    
    alert('تم إتمام عملية البيع بنجاح');
}

// طباعة الفاتورة
function printInvoice(sale) {
    const printWindow = window.open('', '_blank');
    const customer = customers.find(c => c.id === sale.customerId) || { name: 'عميل نقدي' };
    
    printWindow.document.write(`
        <!DOCTYPE html>
        <html dir="rtl">
        <head>
            <title>فاتورة بيع - وصل</title>
            <style>
                body { font-family: Arial, sans-serif; margin: 0; padding: 20px; }
                .invoice-header { text-align: center; margin-bottom: 20px; }
                .invoice-details { margin-bottom: 20px; }
                table { width: 100%; border-collapse: collapse; }
                th, td { border: 1px solid #ddd; padding: 8px; text-align: center; }
                th { background-color: #f2f2f2; }
                .total { font-weight: bold; }
                @media print {
                    .no-print { display: none; }
                    body { padding: 0; }
                }
            </style>
        </head>
        <body>
            <div class="invoice-header">
                <h2>فاتورة بيع</h2>
                <h3>نظام وصل لإدارة المبيعات</h3>
            </div>
            
            <div class="invoice-details">
                <p><strong>رقم الفاتورة:</strong> ${sale.id}</p>
                <p><strong>التاريخ:</strong> ${sale.date.toLocaleDateString()}</p>
                <p><strong>العميل:</strong> ${customer.name}</p>
            </div>
            
            <table>
                <thead>
                    <tr>
                        <th>#</th>
                        <th>المنتج</th>
                        <th>الكمية</th>
                        <th>سعر الوحدة</th>
                        <th>الإجمالي</th>
                    </tr>
                </thead>
                <tbody>
                    ${sale.items.map((item, index) => `
                        <tr>
                            <td>${index + 1}</td>
                            <td>${item.name}</td>
                            <td>${item.quantity}</td>
                            <td>${item.price.toFixed(2)} ر.س</td>
                            <td>${(item.price * item.quantity).toFixed(2)} ر.س</td>
                        </tr>
                    `).join('')}
                </tbody>
                <tfoot>
                    <tr>
                        <td colspan="4" class="total">المجموع</td>
                        <td class="total">${sale.total.toFixed(2)} ر.س</td>
                    </tr>
                </tfoot>
            </table>
            
            <div class="no-print" style="margin-top: 20px; text-align: center;">
                <button onclick="window.print()" style="padding: 10px 20px; background: #4CAF50; color: white; border: none; cursor: pointer;">
                    طباعة الفاتورة
                </button>
                <button onclick="window.close()" style="padding: 10px 20px; background: #f44336; color: white; border: none; cursor: pointer;">
                    إغلاق
                </button>
            </div>
            
            <script>
                window.onload = function() {
                    window.print();
                };
            </script>
        </body>
        </html>
    `);
    
    printWindow.document.close();
}